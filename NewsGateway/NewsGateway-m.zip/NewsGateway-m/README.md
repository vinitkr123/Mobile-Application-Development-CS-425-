# NewsGateway

This app displays current news articles from a wide variety of news sources covering a range of news
categories.
