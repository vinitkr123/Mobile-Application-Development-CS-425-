package iit.vinit.newsgateway;


import android.net.Uri;
import android.os.AsyncTask;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


public class NewsArticleDownloader extends AsyncTask<String, Void, String> {

    private NewsService newsService;
    private String url = "https://newsapi.org/v1/articles?";
    private String key = "d8951f519b574c539347673fdab06de4";
    private ArrayList<Article> newsListArticle = new ArrayList<>();
    private String source;

    public NewsArticleDownloader(NewsService newsService, String source) {
        this.newsService = newsService;
        this.source = source;
    }


    private void parseJSON(String str) {
        try {
            JSONObject jsonObject = new JSONObject(str);
            JSONArray jObjectJSONArray = jsonObject.getJSONArray("articles");
            for (int i = 0; i < jObjectJSONArray.length(); i++) {
                Article articleJson = new Article();
                articleJson.setNewAuthor(jObjectJSONArray.getJSONObject(i).getString("author").replace("null", ""));
                articleJson.setNewsTitle(jObjectJSONArray.getJSONObject(i).getString("title").replace("null", ""));
                articleJson.setApiAddress(jObjectJSONArray.getJSONObject(i).getString("url"));
                articleJson.setUrl2image(jObjectJSONArray.getJSONObject(i).getString("urlToImage"));
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                articleJson.setDt_Time(jObjectJSONArray.getJSONObject(i).getString("publishedAt"));
                articleJson.setNewsDesc(jObjectJSONArray.getJSONObject(i).getString("description"));
                newsListArticle.add(articleJson);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    protected void onPostExecute(String result) {

        parseJSON(result);
        newsService.setArticleList(newsListArticle);
    }

    @Override
    protected String doInBackground(String[] params) {
        Uri.Builder buildURL = Uri.parse(url).buildUpon();
        buildURL.appendQueryParameter("apiKey", key);
        buildURL.appendQueryParameter("source", source);
        String urlToUse = buildURL.build().toString();

        StringBuilder stringBuilder = new StringBuilder();
        try {
            URL url = new URL(urlToUse);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("GET");
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader((new InputStreamReader(inputStream)));

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                stringBuilder.append(line).append('\n');
            }
        } catch (Exception e) {
            return null;
        }
        return stringBuilder.toString();
    }


}
