package com.example.vinit.converter;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    //Global Variable Declaration
    private TextView txtView;
    private EditText editText,textChange ,search_edit;
    private RadioButton radioButton,radioButtonf;
    TextView textViewConverted;
    TextView finalHistory;
    String output,radioText;
    private double F ,C, con;
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        textViewConverted = findViewById(R.id.txt_ConvertedTemp);
        finalHistory = findViewById(R.id.txt_History);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        Log.d(TAG,"OnCreate");

        search_edit = findViewById(R.id.txt_inputTemp);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) { //Function created for deleting the value when edited the editbox

        Log.d(TAG, "onKeyUp: Value of key "+keyCode +event);
        editText = findViewById(R.id.txt_ConvertedTemp);
        editText.setText(null);
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) { //Function created for deleting the value when edited the editbox
        editText = findViewById(R.id.txt_ConvertedTemp);
        editText.setText(null);
        return super.onKeyDown(keyCode, event);
    }

    public void onCreate(View v)
    {
        radioButton = findViewById(R.id.radioCelcius);  //This is onclick function for the button convert
        radioButtonf = findViewById(R.id.radioFahrenheit);
        if(radioButton.isChecked()==false && radioButtonf.isChecked()==false)
        {
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);  //Alert when radio is empty
            alertDialog.setTitle("Message");
            alertDialog.setMessage("Please select at least one Radio");
            alertDialog.setPositiveButton("OK",null);
            alertDialog.setCancelable(true);
            alertDialog.create().show();
        }


       else if(radioButton.isChecked())
        {
            editText  = (findViewById(R.id.txt_inputTemp));
            String val = editText.getText().toString();
            if(val==null || val =="" ||val.equals(""))
            {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(this); //Alert when textbox is empty
                alertDialog.setTitle("Message");
                alertDialog.setMessage("Please Enter a value");
                alertDialog.setPositiveButton("OK",null);
                alertDialog.setCancelable(true);
                alertDialog.create().show();
            }
            else {
                C = getEdittext();

                con = (C * 1.8) + 32;
                resConverted(con);
                //radioText = radioButton.getText().toString() + ": " + C + " ->" + String.format("%.3f", con);
                radioText = "C to F " + ": " + C + " ->" + String.format("%.1f", con);

                Log.d(TAG, "onCreate: To change Celceius to Faherihniet");
                if (!radioText.equals(null)) {
                    showHistory(radioText);
                }
            }
        }else if(radioButtonf.isChecked()) {

            editText = (findViewById(R.id.txt_inputTemp));
            String val = editText.getText().toString();
            if (val == null || val == "" || val.equals("")) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
                alertDialog.setTitle("Message");
                alertDialog.setMessage("Please Enter a value");
                alertDialog.setPositiveButton("OK", null);
                alertDialog.setCancelable(true);
                alertDialog.create().show();
            } else {

                F = getEdittext();
                con = (F - 32.0) / 1.8;
                resConverted(con);
                //radioText = radioButtonf.getText().toString() + ": " + (F) + " ->  " + String.format("%.3f", con);
                radioText = "F to C " + ": " + F + " ->" + String.format("%.1f", con);

                Log.d(TAG, "onCreate: to change from F to C");
                if (!radioText.equals(null)) {
                    showHistory(radioText);
                }
            }
        }
    }



    @Override
    protected void onStart() {
        super.onStart();
    }

    public void resConverted(double s)
    {
        editText = (EditText)(findViewById(R.id.txt_ConvertedTemp));
        editText.setText(String.format("%.1f",Double.valueOf(s)));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public Double getEdittext()   // return the value of input editbox of which temprature is to be converted
    {
        editText  = (findViewById(R.id.txt_inputTemp));
        String val = editText.getText().toString();
        return Double.valueOf(val);
    }


    public void showHistory(String str) { //The function handles the history, saves it and displays in the textView box
        txtView = findViewById(R.id.txt_History);
        output = String.valueOf(txtView.getText());
        txtView.setMovementMethod(new ScrollingMovementMethod());
        for (int i = 0; i < 1; i++) {
            if (output.equals(null) || output.trim() == "") {
                output = str + "\n";
            } else {
                output = str + "\n" + output;
            }
        }
        txtView.setText(output);

    }


    @Override
    protected void onStop() {  //Runs when app goes in Onstop mode
        super.onStop();
    }
    @Override
    protected void onResume()  //Runs when app resumes after pause
    {
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onPause() {  //Runs when app on it goes in pause mode
        super.onPause();
    }

    public void onradioClickCelcius(View view) { //Function empty the editbox when radio is clicked
        editText = (findViewById(R.id.txt_inputTemp));
        editText.setText(null);
        editText = (findViewById(R.id.txt_ConvertedTemp));
        editText.setText(null);

    }

    public void onradioClickFeh(View view) { //Function empty the editbox when radio is clicked
        editText = (findViewById(R.id.txt_inputTemp));
        editText.setText(null);
        editText = (findViewById(R.id.txt_ConvertedTemp));
        editText.setText(null);

    }

    @Override
    public void onSaveInstanceState(Bundle outState){  //This is an inbuild function which helps in Saving the state of instance
        outState.putString("hist",finalHistory.getText().toString());
        outState.putString("convertedVal",textViewConverted.getText().toString());
        super.onSaveInstanceState(outState);
    }


    public void onStartInstanceState(Bundle savedInstanceState) { //Function when Instance is started
        Log.d(TAG, "onRestoreInstanceState: ");
        super.onRestoreInstanceState(savedInstanceState);
        String hist_Rt = savedInstanceState.getString("hist");
        String con_val = savedInstanceState.getString("convertedVal");
        finalHistory.setText(hist_Rt);
        textViewConverted.setText(con_val);
        finalHistory.setMovementMethod(new ScrollingMovementMethod());
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) { //Fucntion works when app restores in from rotation mode
        Log.d(TAG, "onRestoreInstanceState: ");
        super.onRestoreInstanceState(savedInstanceState);

        String hist_Rt = savedInstanceState.getString("hist");
        String con_val = savedInstanceState.getString("convertedVal");
        finalHistory.setText(hist_Rt);
        finalHistory.setMovementMethod(new ScrollingMovementMethod());
        textViewConverted.setText(con_val);
    }



}
