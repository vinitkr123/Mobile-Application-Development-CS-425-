package com.vinit.multinotepad;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import com.vinit.multi_notepad.R;


public class MyViewHolder extends RecyclerView.ViewHolder {


    public TextView symbol;
    public TextView companyNAme;
    public TextView latestPrice;
    public TextView priceChange;
    public TextView percentageChange;

    public MyViewHolder(View view) {
        super(view);
        symbol = (TextView) view.findViewById(R.id.stockSymbol);
        companyNAme = (TextView) view.findViewById(R.id.stockCompagnyName);
        latestPrice = (TextView) view.findViewById(R.id.stockLatestPrice);
        priceChange = (TextView) view.findViewById(R.id.stockChange);
        percentageChange = (TextView) view.findViewById(R.id.stockChangePercent);
    }

}
