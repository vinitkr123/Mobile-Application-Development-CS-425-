package com.vinit.multinotepad;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.vinit.multi_notepad.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener, View.OnLongClickListener{

    private static final String TAG = "MainActivity";
    private List<Stock> stocks = new ArrayList<>();
    private List<String> listSymbol = new ArrayList<>();
    private RecyclerView recyclerView;
    private StockAdapter stockAdapter;
    private SwipeRefreshLayout swipeRefreshLayout;
    private int lastSelectedPos;
    private int count =0;
    private String selectedOne = "";
    private DatabaseHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHandler = new DatabaseHandler(this);
        setContentView(R.layout.activity_main);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerID);
        stockAdapter = new StockAdapter(stocks, this);
        recyclerView.setScrollContainer(true);
        recyclerView.setAdapter(stockAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        dbHandler.dumpLogs();

        setDataFromDb();
        if (networkStatus()){
            stockUpdations();

            stockAdapter.notifyDataSetChanged();
        }else{
            connectionError();
        }
        stockAdapter.notifyDataSetChanged();
        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                stockUpdations();
                swipeRefreshLayout.setRefreshing(false);
            }
        });

    }



    public void remove_Stock(int position){
        dbHandler.delete_Stock(stocks.get(position).getSymbol());
        stocks.remove(position);
        listSymbol.remove(position);
        stockAdapter.notifyDataSetChanged();
    }


    public void addStock(Stock newStock){
        if (! listSymbol.contains(newStock.getSymbol())) {
            dbHandler.addStock(newStock);
            stocks.add(0,newStock);
            listSymbol.add(0,newStock.getSymbol());
            Collections.sort(stocks);
        }

        stockAdapter.notifyDataSetChanged();
    }

   public void emptyDatabase(){
        dbHandler.emptyDB();
        stocks.clear();
        listSymbol.clear();
        stockAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu (Menu menu){
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected (MenuItem menuItem){
        switch (menuItem.getItemId()) {
            case R.id.menu_main_item_add:

                if (networkStatus()){
                    addNewStock();
                }else {
                    connectionError();
                }
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    @Override
    public void onClick(View v) {
        int pos = recyclerView.getChildLayoutPosition(v);
        Stock stock = stocks.get(pos);
        if (networkStatus()){
            goToStock(stock.getSymbol());

        }else {
            connectionError();

        }
    }

    @Override
    public boolean onLongClick(View v) {
        int pos = recyclerView.getChildLayoutPosition(v);
        Stock stock = stocks.get(pos);
        lastSelectedPos = pos;
        final AlertDialog alertDialogDelete = new AlertDialog.Builder(this)
                .setPositiveButton("Yes",dialogClickListenerDelete)
                .setCancelable(false)
                .setTitle("DELETE STOCK")
                .setNegativeButton("No",dialogClickListenerDelete)
                .setMessage("Sure you want to remove " + stock.getSymbol()+" ?")
                .setIcon(android.R.drawable.ic_menu_delete)
                .show();
        return false;
    }

    DialogInterface.OnClickListener dialogClickListenerDelete = new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            switch (which){
                case DialogInterface.BUTTON_POSITIVE:
                    remove_Stock(lastSelectedPos);
                    stockAdapter.notifyDataSetChanged();
                    break;
                case DialogInterface.BUTTON_NEGATIVE:
                    break;
            }
        }
    };

    public void goToStock(String s) {
        String tobeSearch = "http://www.marketwatch.com/investing/stock/" + s;
        Intent intd = new Intent(Intent.ACTION_VIEW);
        intd.setData(Uri.parse(tobeSearch));
        startActivity(intd);
    }

    private boolean networkStatus() {
        boolean x = true;
        Log.d(TAG, "networkStatus: line 1 ");
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) {
            Toast.makeText(this, "Cannot access ConnectivityManager", Toast.LENGTH_SHORT).show();
        }
       //if(connectivityManager.getActiveNetworkInfo().isConnected())
        NetworkInfo netInfo = connectivityManager.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        } else {
            return false;
        }
    }

    private void setDataFromDb(){
        ArrayList<String[]> arrayList = dbHandler.loadStocks();
        for (int i=0; i <arrayList.size(); i++){
            stocks.add(new Stock(arrayList.get(i)[0],arrayList.get(i)[1],0.0,0.0,0.0));
            listSymbol.add(stocks.get(i).getSymbol());
            Collections.sort(stocks);
        }
        //Collections.sort(stocks,Collections.reverseOrder());
    }

    private void connectionError() {
        final AlertDialog alertDialog = new AlertDialog.Builder(this)
                .setTitle("No Network Connection")
                .setMessage("Stocks Cannot Be Added Without A Network Connection")
                .setCancelable(true)
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() { public void onClick(DialogInterface dialog, int id) {    }})
                .show();
    }

    public void duplicateError(String acb) {
        final AlertDialog alertDialogDuplicate = new AlertDialog.Builder(this)
                .setMessage("Stock Symbol "+ acb+" is already displayed")
                .setTitle("Duplicate Stock")
                .setCancelable(true)
                .show();
    }

    private void addNewStock(){
        final EditText input = new EditText(this);
        input.setFilters(new InputFilter[] {new InputFilter.AllCaps()});
        input.setInputType(InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        input.setGravity(Gravity.CENTER_HORIZONTAL);
        AlertDialog builder = new AlertDialog.Builder(this)
                .setMessage("Please enter a Stock Symbol:")
                .setView(input)
                .setTitle("Stock Selection")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {public void onClick(DialogInterface dialog, int which) {
                    lookupStock(input.getText().toString());}})
            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {public void onClick(DialogInterface dialog, int which) {}})
            .show();
    }

    private void lookupStock(String stock){
        if (listSymbol.contains(stock)){
            duplicateError(stock);
        }
        else{
            AsyncTaskSymbol.running = true;

            new AsyncTaskSymbol(this,stock).execute();
        }
    }

    public void whenAsyncTaskSymbolIsDone(List<String[]> listSymbol) {
        if (listSymbol.size() == 0){
            noStockFound(listSymbol);
        }else{
            if (listSymbol.size() == 1){
                //Collections.sort(listSymbol,Collections.<String[]>reverseOrder());
               stockData(listSymbol);
            }else{
             //  Collections.sort(listSymbol,Collections.<String[]>reverseOrder());
                selectStock(listSymbol);
            }
        }
        stockAdapter.notifyDataSetChanged();

    }

    public void whenAsyncTaskStockValuesIsDone (ArrayList<String> listValues){
        if (listValues.size() != 0){

            addStock(new Stock(listValues.get(0),listValues.get(1), Double.parseDouble(listValues.get(2)),Double.parseDouble(listValues.get(3)),Double.parseDouble(listValues.get(4))));

        }else {
            noFinancialDataFound();
        }
    }

    public void noStockFound(List<String[]> listSymbol){
        for (String[] strings : listSymbol) {
            Log.d(TAG, "noStockFound: value in no stock "+Arrays.toString(strings));

        }
        final AlertDialog alertDialog = new AlertDialog.Builder(this)
                .setMessage("Data for stock symbol")
                .setCancelable(true)
                .setNegativeButton("OK", new DialogInterface.OnClickListener() { public void onClick(DialogInterface dialog, int id) {    }})
                .setTitle("Symbol Not Found: ")
                .show();
    }

    public void noFinancialDataFound(){
        final AlertDialog alertDialog = new AlertDialog.Builder(this)
                .setTitle("Error")
                .setCancelable(true)
                .setMessage("No financial data found")
                .setNegativeButton("OK", new DialogInterface.OnClickListener() { public void onClick(DialogInterface dialog, int id) {    }})
                .show();
    }

    public void stockData(List<String[]> listSymbols){
        AsyncTaskStockValues.running = true;
        Collections.sort(listSymbols,Collections.<String[]>reverseOrder());
        new AsyncTaskStockValues(this,listSymbols.get(0)[0]).execute();
    }

    public void update_stockData(String symbol){
        AsyncTaskStockValues.running = true;
        new AsyncTaskStockValues(this,symbol).execute();
    }

    public void selectStock(List<String[]> symbols){
        final String[] listSymbol = new String[symbols.size()];
        String[] listSymbolName = new String[symbols.size()];

        for (int i = 0; i< symbols.size(); i++){
            listSymbol[i]=symbols.get(i)[0];
            if(symbols.contains(listSymbol[i]))
            {
                Log.d(TAG, "selectStock: "+listSymbol[i]);
                duplicateError(listSymbol[i]);
            }
            listSymbolName[i]=symbols.get(i)[0] + "-" + symbols.get(i)[1];
        }

       // Collections.sort(symbols,Collections.<String[]>reverseOrder());
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setTitle("Make a selection");
        alertDialog.setNegativeButton("Nevermind",dialogClickListenerDelete);
        alertDialog.setItems(listSymbolName, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) { open_Stock_Selected(listSymbol[which]);}});
        AlertDialog dialog = alertDialog.create();
        dialog.show();
    }

    public void open_Stock_Selected(String symbol){
        update_stockData(symbol);
    }

    public void stockUpdations(){
        if (networkStatus()){
            int sizeOfList = stocks.size();
            for(int i=0; i< sizeOfList;i++){
                String symbol = stocks.get(stocks.size()-1).getSymbol();
                remove_Stock(stocks.size()-1);
                 update_stockData(symbol);
            }
            Collections.sort(stocks);
        }else{
            connectionError();
        }
        dbHandler.dumpLogs();
        stockAdapter.notifyDataSetChanged();
    }

}
