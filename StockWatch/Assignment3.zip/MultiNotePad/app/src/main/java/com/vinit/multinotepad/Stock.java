package com.vinit.multinotepad;


import android.support.annotation.NonNull;

import java.io.Serializable;

public class Stock implements Serializable,Comparable<Stock>{

    private String symbol;
    private String companyName;
    private Double lastesPrice;
    private Double change;
    private Double currentPercentage;


    public Stock(String symbol,String companyName,Double latestPrice,Double change,Double currentPercentage) {
        this.symbol = symbol;
        this.companyName = companyName;
        this.lastesPrice = latestPrice;
        this.change = change;
        this.currentPercentage = currentPercentage;
    }

    public String getSymbol() { return this.symbol;}
    public String getCompanyName() { return this.companyName;}
    public Double getPriceLatest() { return this.lastesPrice;}
    public Double getChange() { return this.change;}
    public Double getPercentChange() { return this.currentPercentage;}

    public void setSymbol(String newStockSymbol){this.symbol = newStockSymbol;}
    public void setCompanyName(String newStockCompagnyName){this.companyName = newStockCompagnyName;}
    public void setPriceLatest(Double newStockLatestPrice){this.lastesPrice = newStockLatestPrice;}
    public void setChange(Double newStockChange){this.change = newStockChange;}
    public void setPercentChange(Double newStockChangePercent){this.currentPercentage = newStockChangePercent;}

    public String toSaveFormat() {
        return this.symbol + " " + this.companyName + " " + this.lastesPrice + " " + this.change + " " + this.currentPercentage;
    }

    @Override
    public String toString() {
        return this.symbol + " " + this.companyName + " " + this.lastesPrice + " " + this.change + " " + this.currentPercentage;
    }


    @Override
    public int compareTo(@NonNull Stock stock) {

        return getSymbol().compareTo(stock.getSymbol());
    }
}