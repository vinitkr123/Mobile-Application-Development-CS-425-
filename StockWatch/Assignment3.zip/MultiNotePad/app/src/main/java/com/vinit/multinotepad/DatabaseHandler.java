package com.vinit.multinotepad;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Database handler
 */

public class DatabaseHandler extends SQLiteOpenHelper {

    private static final String TBL_NAME = "StockWatchTable";
    private static final String DB_NAME = "StockAppDB";
    private static final int DB_VERSION = 1;
    private static final String STOCKSYMBOL = "Symbol";
    private static final String COMPANYNAME = "CompagnyName";
    private static final String CREATE_TABLE =
            "CREATE TABLE " + TBL_NAME + " (" +
                    STOCKSYMBOL + " TEXT not null unique," +
                    COMPANYNAME + " TEXT not null)";

    private MainActivity mainActivity;
    private SQLiteDatabase database;
    private static final String TAG = "DatabaseHandler";


    public DatabaseHandler(MainActivity context) {
        super(context, DB_NAME, null, DB_VERSION);
        mainActivity = context;
        database = getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }


    public ArrayList<String[]> loadStocks() {

        ArrayList<String[]> listStocks = new ArrayList<>();
        Cursor cursor = database.query(
                TBL_NAME, new String[]{STOCKSYMBOL, COMPANYNAME},null,null, null,null, null);
        if (cursor != null) {
            cursor.moveToFirst();
            for (int i = 0; i < cursor.getCount(); i++) {
                String symbl = cursor.getString(0);
                String cmpmy = cursor.getString(1);
                listStocks.add(new String[] {symbl, cmpmy});
                cursor.moveToNext();
            }
            cursor.close();
        }
        return listStocks;
    }

    public void addStock(Stock stock) {
        ContentValues values = new ContentValues();
        values.put(STOCKSYMBOL, stock.getSymbol());
        values.put(COMPANYNAME, stock.getCompanyName());
        long key = database.insert(TBL_NAME, null, values);
        }


    public void shutDown() {
        database.close();
    }


    public void dumpLogs() {
        Cursor crsr = database.rawQuery("select * from " + TBL_NAME, null);
        if (crsr != null) {
            crsr.moveToFirst();
            for (int j = 0; j < crsr.getCount(); j++) {
                String symbol = crsr.getString(0);
                String compagnyName = crsr.getString(1);
                crsr.moveToNext();
            }
            crsr.close();
        }
    }

    public void emptyDB()
    {
        database.delete(TBL_NAME, null, null);
    }

    public void delete_Stock(String name) {
        int cnt = database.delete(TBL_NAME, STOCKSYMBOL + " = ?", new String[]{name});
 }



    public void update_Stock(Stock stock) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(STOCKSYMBOL, stock.getSymbol());
        contentValues.put(COMPANYNAME, stock.getCompanyName());
        long update = database.update(TBL_NAME, contentValues, STOCKSYMBOL + " = ?", new String[]{stock.getSymbol()});
    }

}