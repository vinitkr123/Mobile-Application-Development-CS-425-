package com.vinit.multinotepad;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.vinit.multi_notepad.R;

public class InfoActivity extends AppCompatActivity {

    private static final String TAG = "InfoActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
