package com.vinit.multinotepad;

import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.vinit.multi_notepad.R;

import java.util.List;

public class StockAdapter extends RecyclerView.Adapter<MyViewHolder> {

    private static final String TAG = "StockAdapter";
    private List<Stock> stockList;
    private MainActivity mainActivity;

    public StockAdapter(List<Stock> stocks, MainActivity mainActivity) {
        this.mainActivity = mainActivity;
        this.stockList = stocks;
    }

    @Override
    public MyViewHolder onCreateViewHolder(final ViewGroup viewGroup, int viewtype) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.list_item, viewGroup, false);
        view.setOnLongClickListener((View.OnLongClickListener) mainActivity);
        view.setOnClickListener(mainActivity);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder myViewHolder, int pos) {
        Stock myStock = stockList.get(pos);
        myViewHolder.companyNAme.setText(myStock.getCompanyName());
        myViewHolder.latestPrice.setText(myStock.getPriceLatest().toString());
        myViewHolder.percentageChange.setText("("+myStock.getPercentChange().toString()+"%)");
        myViewHolder.symbol.setText(myStock.getSymbol());

        if (myStock.getChange() < 0){
            myViewHolder.symbol.setTextColor(Color.parseColor("#FF0040"));
            myViewHolder.percentageChange.setTextColor(Color.parseColor("#FF0040"));
            myViewHolder.priceChange.setText('\u25BC'+myStock.getChange().toString());
            myViewHolder.latestPrice.setTextColor(Color.parseColor("#FF0040"));
            myViewHolder.companyNAme.setTextColor(Color.parseColor("#FF0040"));
            myViewHolder.priceChange.setTextColor(Color.parseColor("#FF0040"));

        }else{
            myViewHolder.percentageChange.setTextColor(Color.parseColor("#00FF00"));
            myViewHolder.symbol.setTextColor(Color.parseColor("#00FF00"));
            myViewHolder.latestPrice.setTextColor(Color.parseColor("#00FF00"));
            myViewHolder.priceChange.setText('\u25B2'+myStock.getChange().toString());
            myViewHolder.priceChange.setTextColor(Color.parseColor("#00FF00"));
            myViewHolder.companyNAme.setTextColor(Color.parseColor("#00FF00"));
        }

    }

    @Override
    public int getItemCount() {
        return stockList.size();
    }

}
