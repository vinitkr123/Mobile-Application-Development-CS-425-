
package com.vinit.multinotepad;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.TreeSet;

public class AsyncTaskSymbol extends AsyncTask<Integer,Integer, String> {

    private static final String TAG = "AsyncTaskSymbol";
    private MainActivity mainActivity;
    public static boolean running = false;
    private boolean check = false;
    private String searchedString;
    private ArrayList<String[]> symbolList = new ArrayList<>();
    private static String urlfixed ="https://api.iextrading.com/1.0/ref-data/symbols";
    ArrayList<HashMap<String, String>> contactList;
    public AsyncTaskSymbol(MainActivity mainActivity, String enteredValue) {
        this.mainActivity = mainActivity;
        searchedString = enteredValue.replaceAll("\\s+","");
        if (searchedString.indexOf('.') != -1 ){
            check = true;
        }
    }

    protected String doInBackground(Integer[] para) {
        if (!check) {
            {
                HttpHandler sh = new HttpHandler();
                String jsonStr = sh.makeServiceCall(urlfixed);
                if (jsonStr != null) {
                    try {
                        JSONArray jsonObj = new JSONArray(jsonStr);
                        for (int i = 0; i < jsonObj.length(); i++) {
                            JSONObject jsonobject = jsonObj.getJSONObject(i);
                            String symbol = jsonobject.getString("symbol");
                            String compnayName = jsonobject.getString("name");
                            if (symbol.startsWith(searchedString)) {

                                symbolList.add(new String[]{symbol, compnayName});

                            }
                        }
                    } catch (final JSONException e) {
                    }
                } else {
                    }
            }
        }
        return "done";
    }
    public String loadJSONFromAsset(Context context) {
        String json = null;
        try {
            InputStream is = context.getAssets().open("file_name.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
        return json;

    }

    @Override
    protected void onPostExecute(String returnValue) {
        super.onPostExecute(returnValue);
        mainActivity.whenAsyncTaskSymbolIsDone(symbolList);
        if(symbolList.contains(returnValue))
        {
            MainActivity ma = new MainActivity();
            ma.duplicateError(returnValue);}
        running = false;
    }


}