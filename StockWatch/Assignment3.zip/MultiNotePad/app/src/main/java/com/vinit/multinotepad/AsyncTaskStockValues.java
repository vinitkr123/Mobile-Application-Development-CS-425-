package com.vinit.multinotepad;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;


public class AsyncTaskStockValues extends AsyncTask<Integer,Integer, String> {

    private MainActivity mainactivity;
    public static boolean running = false;
    private String url_End = "/quote";
    private ArrayList<String> values = new ArrayList<>();
    private String URL = "https://api.iextrading.com/1.0/stock/";
    private String requestedSymbol;
    String empty;
    private static final String TAG = "AsyncTaskStockValues";

    public AsyncTaskStockValues(MainActivity mainActivity, String symbol) {
        requestedSymbol = symbol;
        this.mainactivity = mainActivity;
    }
    @Override
    protected String doInBackground(Integer[] para) {
        String fixedURL = URL + requestedSymbol + url_End;
        StringBuilder stringBuilder = new StringBuilder();
        try {
            URL value = new URL(fixedURL);
            HttpURLConnection httpURLConnection = (HttpURLConnection) value.openConnection();
            httpURLConnection.setRequestMethod("GET");
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

            while ((empty = bufferedReader.readLine()) != null) {
                stringBuilder.append(empty).append('\n');
            }
            getData(stringBuilder.toString());
        } catch (Exception e) {
            e.getStackTrace();
        }
        return "done";
    }


    public void getData(String s){
        try{

            if(!s.equals("httpserver.cc: Response Code 404")){
                JSONObject jsonQuery =new JSONObject(s);

                String stockSymbol = jsonQuery.getString("symbol");
                String companyName = jsonQuery.getString("companyName");
                String price = jsonQuery.getString("latestPrice");
                String stockChange = jsonQuery.getString("change");
                String percent = jsonQuery.getString("changePercent");
                values.add(stockSymbol);
                values.add(companyName);
                values.add(price);
                values.add(stockChange);
                values.add(percent);

            }
            } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onPostExecute(String val) {
        mainactivity.whenAsyncTaskStockValuesIsDone(values);
        super.onPostExecute(val);
        running = false;
         }

}
