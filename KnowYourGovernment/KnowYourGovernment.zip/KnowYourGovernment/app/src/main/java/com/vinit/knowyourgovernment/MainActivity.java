package com.vinit.knowyourgovernment;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener, View.OnLongClickListener {

    private static final String TAG = "MainActivity";
    private MainActivity mainActivity = this;
    private RecyclerView recyclerview;
    private List<Official> officialList = new ArrayList<>();
    private Adaptar adapter;

    private TextView txtLocation;
    private Locator locator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().getDecorView().setBackgroundColor( getResources().getColor( R.color.purple));
        recyclerview = findViewById(R.id.recycler_main);
        adapter = new Adaptar(officialList, this);
        recyclerview.setAdapter(adapter);
        recyclerview.setLayoutManager(new LinearLayoutManager(this));

        txtLocation = findViewById(R.id.loc_ID);
        txtLocation.setTextColor(getResources().getColor(R.color.white));

        if(connectivityManager()) {
            locator = new Locator(this);
            locator.sleepTime();
        } else{
            txtLocation.setText("No data for location");
            NetworkConnection();
        }
    }

    public void setOfficialList(Object[] results){
        if(results == null){
            txtLocation.setText("No Data For Location");
            officialList.clear();
        }
        else{
            txtLocation.setText(results[0].toString());
            officialList.clear();
            ArrayList<Official> offList = (ArrayList<Official>) results[1];
            for(int i = 0; i < offList.size(); i++){
                officialList.add(offList.get(i));
            }
        }
        adapter.notifyDataSetChanged();
    }



    public void findAddress(double lat, double longi) {
        List<Address> adress = null;
            Geocoder coder = new Geocoder(this, Locale.getDefault());
            try {
                adress = coder.getFromLocation(lat, longi, 1);
                Address ad = adress.get(0);
                String postalCode = ad.getPostalCode();
                new AsyncLoader(mainActivity).execute(postalCode);
            } catch (IOException e) {
                Toast.makeText(mainActivity,"No address cannot be captured from provided details of latitude/longitude", Toast.LENGTH_SHORT).show();
            }
    }

    public void noRelocationAvailable() {
        Toast.makeText(mainActivity,"No Location Available", Toast.LENGTH_SHORT).show();

    }


    @Override
    public void onClick(View v){
        Intent intent = new Intent(MainActivity.this, Activity.class);
        int position = recyclerview.getChildLayoutPosition(v);
        Official official = officialList.get(position);
        intent.putExtra("header", txtLocation.getText().toString() );
        Bundle bundle = new Bundle();
        bundle.putSerializable("activityOfficial", official);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    @Override
    public boolean onLongClick(View view){
        recyclerview.getChildLayoutPosition(view);
        onClick(view);
        return false;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.action_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.location:
                if(connectivityManager()){
                    alertDialog();
                }
                else{
                    NetworkConnection();
                }
                return true;
            case R.id.about:
                Intent intent = new Intent(MainActivity.this, AboutActivity.class);
                startActivity(intent);
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void alertDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final EditText editText = new EditText(this);
        editText.setInputType(InputType.TYPE_CLASS_TEXT );
        editText.setGravity(Gravity.CENTER_HORIZONTAL);

        builder.setView(editText);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                String input = editText.getText().toString();
                new AsyncLoader(mainActivity).execute(input);

            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Log.d(TAG, "onClick: Cancel clicked, do nothing");

            }
        });
        builder.setMessage("Enter a City, State, or Zip Code:");
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private boolean connectivityManager(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    public void NetworkConnection(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("No Internet Connection! Data cannot be loaded.");
        builder.setTitle("Network Connection Error");
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] prmession, int[] results) {
        if (requestCode == 5) {
            for (int i = 0; i < prmession.length; i++) {
                if (prmession[i].equals(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    if (results[i] == PackageManager.PERMISSION_GRANTED) {
                        locator.AddressManager();
                        locator.checkLocation();
                        super.onRequestPermissionsResult(requestCode,prmession,results);
                    } else {
                        Toast.makeText(this, "Location permission denied. Cannot determine address", Toast.LENGTH_LONG).show();
                    }
                }
            }
        }
    }

    @Override
    protected void onResume(){
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop(){
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

}