package com.vinit.knowyourgovernment;

import android.content.Context;
import android.graphics.Color;
import android.content.Intent;
import android.net.NetworkInfo;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.Menu;
import android.widget.TextView;
import android.widget.ImageView;
import com.squareup.picasso.Picasso;


public class PhotoActivity extends AppCompatActivity {

    public static final String TAG = "PhotoActivity";
    public TextView txtOfficeView;
    public static final String NODATA = "No Data Provided";
    public static final String UNKNOWN = "Unknown";
    public TextView txtNameView;
    public TextView txt_locationView;
    public ImageView txt_imageView;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setBackgroundColor(Color.BLACK);
        setContentView(R.layout.activity_photo);

        txtOfficeView = findViewById(R.id.getofficeID);
        txt_locationView = findViewById(R.id.loc_ID);
        txt_imageView = findViewById(R.id.image_ID);
        txtNameView = findViewById(R.id.getnameID);

        Intent intent = this.getIntent();
        String txt_header = intent.getStringExtra("header");
        txt_locationView.setText(txt_header.toString());
        txtOfficeView.setText(intent.getStringExtra("office"));
        txtNameView.setText(intent.getStringExtra("name"));
        String color = intent.getStringExtra("color");
        if (color.equals("red")) {
            getWindow().getDecorView().setBackgroundColor(getResources().getColor(R.color.darkRed));
        }
        if (color.equals("blue")) {
            getWindow().getDecorView().setBackgroundColor(getResources().getColor(R.color.darkBlue));
        }
        if(color.equals("black")){
        }

        if(isConnected()) {
            final String photoUrl = intent.getStringExtra("photoUrl");
            Picasso picasso = new Picasso.Builder(this).listener(new Picasso.Listener() {
                @Override
                public void onImageLoadFailed(Picasso picasso, Uri uri, Exception exception) {
                    final String changedUrl = photoUrl.replace("http:", "https:");
                    Log.d(TAG, "onImageLoadFailed: AAA");
                    picasso.load(changedUrl)
                            .error(R.drawable.brokenimage)
                            .placeholder(R.drawable.placeholder)
                            .into(txt_imageView);

                }
            }).build();

            picasso.load(photoUrl)
                    .error(R.drawable.brokenimage)
                    .placeholder(R.drawable.placeholder)
                    .into(txt_imageView);
        } else{
            txt_imageView.setImageResource(R.drawable.placeholder);
        }

    }
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.backpress,menu);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private boolean isConnected(){
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }

}