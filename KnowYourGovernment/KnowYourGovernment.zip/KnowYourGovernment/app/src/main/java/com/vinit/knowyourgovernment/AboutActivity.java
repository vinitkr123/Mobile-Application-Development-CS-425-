package com.vinit.knowyourgovernment;

import android.os.Bundle;
import android.widget.TextView;
import android.support.v7.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {

    private static final String TAG = "AboutActivity";
    private TextView txtTitleView;
    private TextView copyRight;
    private TextView txtVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        copyRight = findViewById(R.id.copyrightID);
        txtTitleView = findViewById(R.id.titleID);
        txtVersion = findViewById(R.id.versionID);

        txtVersion.setText("Version 1.0");
        copyRight.setText("© 2018, Vinit Kumar Kamboj");
        txtTitleView.setText("Know Your Government");
    }
}
