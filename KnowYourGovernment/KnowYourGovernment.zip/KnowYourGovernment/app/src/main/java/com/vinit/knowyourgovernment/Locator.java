package com.vinit.knowyourgovernment;

import android.Manifest;
import android.content.pm.PackageManager;
import android.content.Context;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.Location;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.app.ActivityCompat;
import android.widget.Toast;

public class Locator {

    private MainActivity mActivity;
    private static final String TAG = "Locator";
    private LocationListener loc_istener;
    private LocationManager loc_Managerer;

    public Locator(MainActivity activity){
        mActivity = activity;

        if(checkPermission()){
            AddressManager();
            checkLocation();
        }
    }

    public void AddressManager(){
        if(loc_Managerer != null){return;}
        if(!checkPermission()){ return;}
        loc_Managerer = (LocationManager) mActivity.getSystemService(Context.LOCATION_SERVICE);

        loc_istener = new LocationListener() {
            @Override
            public void onLocationChanged(Location loc) {
                mActivity.findAddress(loc.getLatitude(), loc.getLongitude());
            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {

            }
        };

        loc_Managerer.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,1000, 0, loc_istener);

    }

    public void sleepTime(){
        loc_Managerer.removeUpdates(loc_istener);
        loc_Managerer = null;
    }

    public android.location.LocationListener getLocationListener() {
        return loc_istener;
    }

   public void checkLocation(){

        if(!checkPermission()){return;}

        if(loc_Managerer == null){
            AddressManager();}

       if (loc_Managerer != null) {
           Location knownLocation = loc_Managerer.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
           if (knownLocation != null) {
               mActivity.findAddress(knownLocation.getLatitude(), knownLocation.getLongitude());
               Toast.makeText(mActivity, "Using " + LocationManager.NETWORK_PROVIDER + " Location provider", Toast.LENGTH_SHORT).show();
               return;
           }
       }

       if (loc_Managerer != null) {
           Location knownLocation = loc_Managerer.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);
           if (knownLocation != null) {
               mActivity.findAddress(knownLocation.getLatitude(), knownLocation.getLongitude());
               Toast.makeText(mActivity, "Using " + LocationManager.PASSIVE_PROVIDER + " Location provider", Toast.LENGTH_SHORT).show();
               return;
           }
       }

       if (loc_Managerer != null) {
           Location knownLocation = loc_Managerer.getLastKnownLocation(LocationManager.GPS_PROVIDER);
           if (knownLocation != null) {
               mActivity.findAddress(knownLocation.getLatitude(), knownLocation.getLongitude());
               Toast.makeText(mActivity, "Using " + LocationManager.GPS_PROVIDER + " Location provider", Toast.LENGTH_SHORT).show();
               return;
           }
       }


       mActivity.noRelocationAvailable();
       return;
   }

   private boolean checkPermission(){
       if (ContextCompat.checkSelfPermission(mActivity, Manifest.permission.ACCESS_FINE_LOCATION) !=
               PackageManager.PERMISSION_GRANTED) {
           ActivityCompat.requestPermissions(mActivity,
                   new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 5);
           return false;
       }
       return true;
   }
}
