package com.vinit.knowyourgovernment;

import android.net.Uri;
import android.util.Log;
import android.os.AsyncTask;
import android.widget.Toast;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.ArrayList;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.InputStream;
import java.net.URL;
import java.net.HttpURLConnection;


public class AsyncLoader extends AsyncTask<String, Void, String> {

    private MainActivity mainActivity;
    private static final String TAG = "AsyncLoader";
    private final String dataURLStem = "https://www.googleapis.com/civicinfo/v2/representatives?key="+ KEYSTRING +"&address=";
    private static final String KEYSTRING = "AIzaSyAgrZk7wCajD8EUFnJRm808qn9pGOs6bJQ";
    public static final String NODATA = "No Data Provided";
    public static final String UNKNOWN = "Unknown";
    private String postalCode;
    private String city;
    private String state;

    public AsyncLoader(MainActivity ma){ mainActivity = ma;}

    @Override
    protected void onPreExecute(){
        Log.d(TAG, "onPreExecute: ");
    }

    @Override
    protected void onPostExecute(String result){
        try {
            if (result == null) {
                Toast.makeText(mainActivity, "Data not available at CivicInfo Service", Toast.LENGTH_SHORT).show();
                mainActivity.setOfficialList(null);
                return;
            }
            if (result.isEmpty()) {
                Toast.makeText(mainActivity, "No data available for the specified location", Toast.LENGTH_SHORT).show();
                mainActivity.setOfficialList(null);
                return;
            }

            ArrayList<Official> officialList = fetchJSONData(result);
            Object[] objects = new Object[2];
            if (city.equals("")) {
                objects[0] = state + " " + postalCode;
            } else {
                objects[0] = city + ", " + state + " " + postalCode;
            }
            objects[1] = officialList;
            mainActivity.setOfficialList(objects);
        }catch (Exception e)
        {e.printStackTrace();}
        return;

    }

    @Override
    protected String doInBackground(String... params){
        String urlString = dataURLStem + params[0];
        Uri dataUri = Uri.parse(urlString);
        String toString = dataUri.toString();
        StringBuilder stringBuilder = new StringBuilder();
        try {
            URL url = new URL(toString);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("GET");
            InputStream urlConnectionInputStream = httpURLConnection.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(urlConnectionInputStream)));
            String str;
            while ((str = reader.readLine()) != null) {
                stringBuilder.append(str).append('\n');
            }
        }
        catch (Exception e) {
            return null;
        }
     return stringBuilder.toString();

    }

    private ArrayList<Official> fetchJSONData(String s){

        ArrayList<Official> officialList = new ArrayList<>();
        try{
            JSONObject jsonObject = new JSONObject(s);
            JSONObject normalizedJSONInput = jsonObject.getJSONObject("normalizedInput");
            JSONArray detailOffices = jsonObject.getJSONArray("offices");
            JSONArray detailsOfficials = jsonObject.getJSONArray("officials");
            city = normalizedJSONInput.getString("city");
            state = normalizedJSONInput.getString("state");
            postalCode = normalizedJSONInput.getString("zip");

            for(int i = 0;i < detailOffices.length(); i++){
                JSONObject JSONobj = detailOffices.getJSONObject(i);
                String Office_name = JSONobj.getString("name");
                String indices1 = JSONobj.getString("officialIndices");
                String tmp = indices1.substring(1,indices1.length()-1);
                String [] temp2 = tmp.split(",");
                int [] ints = new int [temp2.length];
                for(int j = 0; j < temp2.length; j++){
                    ints[j] = Integer.parseInt(temp2[j]);
                }

                for(int j = 0; j < ints.length; j++ ){
                    JSONObject innerJSONObj = detailsOfficials.getJSONObject(ints[j]);
                    String name = innerJSONObj.getString("name");
                    String address = "";
                    if(! innerJSONObj.has("address")){
                        address = NODATA;
                    }
                    else {
                        JSONArray address_Array = innerJSONObj.getJSONArray("address");
                        JSONObject adrs_Obj = address_Array.getJSONObject(0);

                        if (adrs_Obj.has("line1")) {
                            address += adrs_Obj.getString("line1") + "\n";
                        }
                        if (adrs_Obj.has("line2")) {
                            address += adrs_Obj.getString("line2") + "\n";
                        }
                        if (adrs_Obj.has("city")) {
                            address += adrs_Obj.getString("city") + " ";
                        }
                        if (adrs_Obj.has("state")) {
                            address += adrs_Obj.getString("state") + ", ";
                        }
                        if (adrs_Obj.has("zip")) {
                            address += adrs_Obj.getString("zip");
                        }

                    }

                    String party_nm = (innerJSONObj.has("party") ? innerJSONObj.getString("party") : UNKNOWN );
                    String phones_num = ( innerJSONObj.has("phones") ? innerJSONObj.getJSONArray("phones").getString(0) : NODATA);
                    String urls_found = ( innerJSONObj.has("urls") ? innerJSONObj.getJSONArray("urls").getString(0) : NODATA);
                    String emails = (innerJSONObj.has("emails") ? innerJSONObj.getJSONArray("emails").getString(0) : NODATA);
                    String photoURL = (innerJSONObj.has("photoUrl") ? innerJSONObj.getString("photoUrl") : NODATA);
                    JSONArray nameLink = ( innerJSONObj.has("channels") ? innerJSONObj.getJSONArray("channels") : null );
                    String googleplus = ""; String facebook = ""; String twitter = ""; String youtube = "";
                    if(nameLink != null){
                        for(int k = 0; k < nameLink.length(); k++ ){
                            String type = nameLink.getJSONObject(k).getString("type");
                            switch (type){
                                case "GooglePlus":
                                    googleplus = nameLink.getJSONObject(k).getString("id");
                                    break;
                                case "Facebook":
                                    facebook = nameLink.getJSONObject(k).getString("id");
                                    break;
                                case "Twitter":
                                    twitter = nameLink.getJSONObject(k).getString("id");
                                    break;
                                case "YouTube":
                                    youtube = nameLink.getJSONObject(k).getString("id");
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                    else{
                        googleplus = NODATA; facebook = NODATA;
                        twitter = NODATA; youtube = NODATA;
                    }
                    Official o = new Official(name, Office_name, party_nm,
                            address, phones_num, urls_found, emails, photoURL,
                            googleplus, facebook, twitter, youtube);
                    officialList.add(o);
                }
            }

            return officialList;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
}