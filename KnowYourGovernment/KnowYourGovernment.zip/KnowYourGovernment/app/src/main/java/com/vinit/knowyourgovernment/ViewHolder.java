package com.vinit.knowyourgovernment;

import android.view.View;
import android.widget.TextView;
import android.support.v7.widget.RecyclerView;


public class ViewHolder extends RecyclerView.ViewHolder {

    public TextView txtViewOfc;
    public TextView txtViewName;

    public ViewHolder(View vw){
        super(vw);
        txtViewOfc = vw.findViewById(R.id.getofficeID);
        txtViewName = vw.findViewById(R.id.getnameID);

    }

}
