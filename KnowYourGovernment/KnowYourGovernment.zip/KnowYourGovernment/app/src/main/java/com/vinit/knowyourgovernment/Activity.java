package com.vinit.knowyourgovernment;

import android.content.pm.PackageManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.text.util.Linkify;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View;

import com.squareup.picasso.Picasso;

public class Activity extends AppCompatActivity {

    public static final String TAG  = "Activity";
    public static final String NO_DATA = "No Data Provided"; // for else
    public static final String UNKNOWN = "Unknown"; // for party
    public static final String DEMOCRATIC = "Democratic";
    public static final String DEM_2 = "Democrat"; // Rahm Emanuel
    public static final String REPUBLICAN = "Republican";

    public TextView location;
    public TextView ofc_view;
    public TextView name;
    public TextView view_party;
    public ImageView image_View;
    public TextView adrs_view;
    public TextView phone_View;
    public TextView _emailView;
    public TextView web_View;

    public TextView adrs_lbl;
    public TextView lbl_phone;
    public TextView lbl_email;
    public TextView lbl_website;

    public ImageView btn_youtube;
    public ImageView btn_googleplus;
    public ImageView btn_twitter;
    public ImageView btn_facebook;

    public Official activityOfficial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_official);
        getWindow().getDecorView().setBackgroundColor(Color.BLACK);
        location = findViewById(R.id.loc_ID); location.setTextColor(Color.WHITE);
        ofc_view = findViewById(R.id.getofficeID);
        name = findViewById(R.id.getnameID);
        image_View = findViewById(R.id.image_ID);
        view_party = findViewById(R.id.party_ID);
        adrs_view = findViewById(R.id.address_ID);
        phone_View = findViewById(R.id.phone_ID);
        web_View = findViewById(R.id.webID);
        _emailView = findViewById(R.id.emailAddress);
        this.lbl_phone = findViewById(R.id.lablePhoneID);
        this.adrs_lbl = findViewById(R.id.labelAddress);
        this.lbl_email = findViewById(R.id.labelEmailID);
        adrs_lbl.setText(("Address:").toString());
        this.lbl_website = findViewById(R.id.labelWebID);
        lbl_phone.setText(("Phone:").toString());
        lbl_email.setText(("Email:").toString());
        adrs_lbl.setTextColor(Color.WHITE);
        lbl_website.setText(("Website:").toString());
        lbl_email.setTextColor(Color.WHITE);
        lbl_phone.setTextColor(Color.WHITE);
        lbl_website.setTextColor(Color.WHITE);


        this.btn_youtube = findViewById(R.id.youtubeButton);
        this.btn_twitter = findViewById(R.id.twitterButton);
        this.btn_googleplus = findViewById(R.id.googleplusButton);
        this.btn_facebook = findViewById(R.id.facebookButton);

        btn_youtube.setImageResource(R.drawable.youtubeicon);
        btn_twitter.setImageResource(R.drawable.twittericon);
        btn_googleplus.setImageResource(R.drawable.googleplusicon);

        btn_facebook.setImageResource(R.drawable.facebookicon);
        Intent intent = this.getIntent();
        Bundle bundle = intent.getExtras();
        activityOfficial = (Official) bundle.getSerializable("activityOfficial");
        location.setText(intent.getStringExtra("header"));
        if( activityOfficial.getOffice().equals(NO_DATA)){ hideView(ofc_view);}
        else{
            ofc_view.setText(activityOfficial.getOffice());
            ofc_view.setTextColor(Color.WHITE);}
        if( activityOfficial.getName().equals(NO_DATA)){ hideView(name);}
        else{
            name.setText(activityOfficial.getName());
            name.setTextColor(Color.WHITE);}
        if( activityOfficial.getParty().equals(UNKNOWN)){ hideView(view_party);}
        else{
            view_party.setText("(" + activityOfficial.getParty() + ")"); view_party.setTextColor(Color.WHITE);
            if(activityOfficial.getParty().equals(DEMOCRATIC) || activityOfficial.getParty().equals(DEM_2)){
                getWindow().getDecorView().setBackgroundColor(getResources().getColor(  R.color.darkBlue));
            }
            if(activityOfficial.getParty().equals(REPUBLICAN)){
                getWindow().getDecorView().setBackgroundColor( getResources().getColor(  R.color.darkRed));
            }
        }

        if(ConnectivityManager()) {
            image_View.setImageResource(R.drawable.placeholder);
            if (activityOfficial.getPhotoUrl().equals(NO_DATA)) {
                image_View.setImageResource(R.drawable.missingimage);
            } else {
                final String activityOfficialPhotoUrl = activityOfficial.getPhotoUrl();
                Picasso picasso = new Picasso.Builder(this).listener(new Picasso.Listener() {
                    @Override
                    public void onImageLoadFailed(Picasso picasso, Uri uri, Exception exception) {
                        final String changedUrl = activityOfficialPhotoUrl.replace("http:", "https:");
                        picasso.load(changedUrl)
                                .error(R.drawable.brokenimage)
                                .placeholder(R.drawable.placeholder)
                                .into(image_View);

                    }
                }).build();

                picasso.load(activityOfficialPhotoUrl)
                        .error(R.drawable.brokenimage)
                        .placeholder(R.drawable.placeholder)
                        .into(image_View);
            }

        } else {
            image_View.setImageResource(R.drawable.placeholder);
        }
        adrs_view.setText(activityOfficial.getAddress()); adrs_view.setTextColor(Color.WHITE);
        phone_View.setText(activityOfficial.getPhone()); phone_View.setTextColor(Color.WHITE);
        _emailView.setText(activityOfficial.getEmail()); _emailView.setTextColor(Color.WHITE);
        web_View.setText(activityOfficial.getUrl()); web_View.setTextColor(Color.WHITE);

        if(activityOfficial.getYoutube().equals(NO_DATA)){
            hideView(btn_youtube);
        }
        if(activityOfficial.getGoogleplus().equals(NO_DATA)){
            hideView(btn_googleplus);
        }
        if(activityOfficial.getFacebook().equals(NO_DATA)){
            hideView(btn_facebook);
        }
        if(activityOfficial.getTwitter().equals(NO_DATA)){
            hideView(btn_twitter);
        }
        Linkify.addLinks(adrs_view,Linkify.MAP_ADDRESSES);
        Linkify.addLinks(phone_View,Linkify.PHONE_NUMBERS);
        Linkify.addLinks(_emailView,Linkify.EMAIL_ADDRESSES);
        Linkify.addLinks(web_View,Linkify.WEB_URLS);

    }

    private static void hideView(View v){
        v.setVisibility(View.GONE);
    }

    public void openPhotoActivity(View v){
        if(activityOfficial.getPhotoUrl().equals(NO_DATA)){
            return;
        }
        Intent intent = new Intent(Activity.this, PhotoActivity.class);
        intent.putExtra("header", location.getText().toString());
        intent.putExtra("office", activityOfficial.getOffice());
        intent.putExtra("name", activityOfficial.getName());

        if(activityOfficial.getParty().equals(DEMOCRATIC) || activityOfficial.getParty().equals(DEM_2)){
            intent.putExtra("color","blue");
        }
        if(activityOfficial.getParty().equals(REPUBLICAN)){
            intent.putExtra("color","red");
        }
        if(activityOfficial.getParty().equals(UNKNOWN)){
            intent.putExtra("color", "black");
        }
        intent.putExtra("photoUrl", activityOfficial.getPhotoUrl());

        startActivity(intent);

    }

    public void youtubeClicked(View v){
        String youtube = activityOfficial.getYoutube();
        Intent intent;
        try {
            intent = new Intent(Intent.ACTION_VIEW);
            intent.setPackage("com.google.android.youtube");
            intent.setData(Uri.parse("https://www.youtube.com/" + youtube));
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,

                    Uri.parse("https://www.youtube.com/" + youtube)));

        }
    }

    public void gplusClickedd(View v){
        String googleplus = activityOfficial.getGoogleplus();
        Intent intent;
        try {
            intent = new Intent(Intent.ACTION_VIEW);
            intent.setClassName("com.google.android.apps.plus",
                    "com.google.android.apps.plus.phone.UrlGatewayActivity");
            intent.putExtra("customAppUri", googleplus);
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,

                    Uri.parse("https://plus.google.com/" + googleplus)));
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.backpress,menu);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public void twitterClicked(View v){
        Intent intent;
        String twitter = activityOfficial.getTwitter();
        try {
            getPackageManager().getPackageInfo("com.twitter.android",0);
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("twitter://user?screen_name=" + twitter));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }catch (Exception e){
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://twitter.com/" + twitter));
        }
        startActivity(intent);
    }
    public void facebookClicked(View v){
        String FACEBOOK_URL = "https://www.facebook.com/" + activityOfficial.getFacebook();
        String stringurl;

        PackageManager manager = getPackageManager();
        try {
            int versionCode = manager.getPackageInfo("com.facebook.katana", 0).versionCode;
            if (versionCode >= 3002850) {
                stringurl = "fb://facewebmodal/f?href=" + FACEBOOK_URL;
            } else {
                stringurl = "fb://page/" + activityOfficial.getFacebook();
            }
        } catch (PackageManager.NameNotFoundException e) {
            stringurl = FACEBOOK_URL;
        }
        Intent facebookIntent = new Intent(Intent.ACTION_VIEW);
        facebookIntent.setData(Uri.parse(stringurl));
        startActivity(facebookIntent);
    }


    private boolean ConnectivityManager(){
        ConnectivityManager systemService = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = systemService.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }



}