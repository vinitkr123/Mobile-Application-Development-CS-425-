package com.vinit.knowyourgovernment;

import java.io.Serializable;


public class Official implements Serializable {

    public static final String NODATA = "No Data Provided";
    public static final String UNKNOWN = "Unknown";

    private String strgooglePlus;
    private String strPhoto;
    private String str_twitter;
    private String str_fb;
    private String str_youtube;
    private String str_name;
    private String str_office;
    private String str_address;
    private String str_party;
    private String str_email;
    private String str_phone;
    private String str_url;


    public Official() {
        this.str_name = NODATA;
        this.str_party = UNKNOWN;
        this.str_office = NODATA;
        this.str_phone = NODATA;
        this.str_address = NODATA;
        this.str_email = NODATA;
        this.str_url = NODATA;
        this.strgooglePlus = NODATA;
        this.strPhoto = NODATA;
        this.str_fb = NODATA;
        this.str_youtube = NODATA;
        this.str_twitter = NODATA;
    }

    public Official(String str_name, String str_office, String str_party, String str_address, String str_phone, String str_url, String str_email, String str_photoUrl, String str_googleplus, String str_facebook, String str_twitter, String str_youtube) {
        this.str_name = str_name;
        this.str_party = str_party;
        this.str_phone = str_phone;
        this.str_office = str_office;
        this.str_address = str_address;
        this.strPhoto = str_photoUrl;
        this.str_email = str_email;
        this.strgooglePlus = str_googleplus;
        this.str_fb = str_facebook;
        this.str_twitter = str_twitter;
        this.str_youtube = str_youtube;
        this.str_url = str_url;
    }

    public String getName() {
        return str_name;
    }

    public void setName(String name) {
        this.str_name = name;
    }

    public String getParty() {
        return str_party;
    }

    public void setParty(String party) {
        this.str_party = party;
    }

    public String getOffice() {
        return str_office;
    }

    public void setOffice(String office) {
        this.str_office = office;
    }

    public String getPhone() {
        return str_phone;
    }

    public void setPhone(String phone) {
        this.str_phone = phone;
    }

    public String getAddress() {
        return str_address;
    }

    public void setAddress(String address) {
        this.str_address = address;
    }

    public String getUrl() {
        return str_url;
    }

    public void setUrl(String url) {
        this.str_url = url;
    }

    public String getEmail() {
        return str_email;
    }

    public void setEmail(String email) {
        this.str_email = email;
    }

    public String getPhotoUrl() {
        return strPhoto;
    }

    public void setPhotoUrl(String photoUrl) {
        this.strPhoto = photoUrl;
    }

    public String getGoogleplus() {
        return strgooglePlus;
    }

    public void setGoogleplus(String googleplus) {
        this.strgooglePlus = googleplus;
    }

    public String getFacebook() {
        return str_fb;
    }

    public void setFacebook(String facebook) {
        this.str_fb = facebook;
    }

    public String getTwitter() {
        return str_twitter;
    }

    public void setTwitter(String twitter) {
        this.str_twitter = twitter;
    }

    public String getYoutube() {
        return str_youtube;
    }

    public void setYoutube(String youtube) {
        this.str_youtube = youtube;
    }

    @Override
    public String toString() {
        return "Official{" +
                "str_name='" + str_name + '\'' +
                ", str_office='" + str_office + '\'' +
                ", str_party='" + str_party + '\'' +
                ", str_address='" + str_address + '\'' +
                ", str_phone='" + str_phone + '\'' +
                ", str_url='" + str_url + '\'' +
                ", str_email='" + str_email + '\'' +
                ", strPhoto='" + strPhoto + '\'' +
                ", strgooglePlus='" + strgooglePlus + '\'' +
                ", str_fb='" + str_fb + '\'' +
                ", str_twitter='" + str_twitter + '\'' +
                ", str_youtube='" + str_youtube + '\'' +
                '}';
    }
}
