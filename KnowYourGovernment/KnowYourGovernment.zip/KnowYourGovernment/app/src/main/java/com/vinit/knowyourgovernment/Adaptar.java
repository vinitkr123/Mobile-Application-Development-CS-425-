package com.vinit.knowyourgovernment;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;

import java.util.List;

public class Adaptar extends RecyclerView.Adapter<ViewHolder> {

    public static final String TAG = "Adaptar";
    private List<Official> list_Official;
    private MainActivity mActivity;


    @Override
    public ViewHolder onCreateViewHolder(final ViewGroup viewGroup, int viewType){
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.official_list_row2, viewGroup, false);
        view.setOnClickListener(mActivity);
        view.setOnLongClickListener(mActivity);
        return new ViewHolder(view);

    }

    public Adaptar(List<Official> officialList, MainActivity activity){
        this.list_Official = officialList;
        mActivity = activity;
    }

    @Override
    public int getItemCount(){ return list_Official.size();}

    @Override
    public void onBindViewHolder(ViewHolder viewholder, int pos){
        Official official = list_Official.get(pos);
        viewholder.txtViewName.setText(String.format("%s (%s)",official.getName(),official.getParty()));
        viewholder.txtViewOfc.setText(official.getOffice());
    }
}
