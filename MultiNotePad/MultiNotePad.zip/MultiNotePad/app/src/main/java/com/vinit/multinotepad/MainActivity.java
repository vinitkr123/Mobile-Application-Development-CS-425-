package com.vinit.multinotepad;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.JsonWriter;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.vinit.multi_notepad.R;

import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener, View.OnLongClickListener {
    private static final String TAG = "MainActivity";
    private static final int EDIT_REQUEST_CODE = 1;
    private static final int CREATE_REQUEST_CODE = 2;
    private List<Note> listNote = new ArrayList<>();
    private RecyclerView recyclerView;
    private NoteAdapter nAdaptar;
    private int lastPosition = 0;
    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            switch (which) {
                case DialogInterface.BUTTON_POSITIVE:
                    listNote.remove(lastPosition);
                    nAdaptar.notifyDataSetChanged();
                    break;

                case DialogInterface.BUTTON_NEGATIVE:
                    break;
            }
        }
    };

    @Override
    protected void onPause() {
        saveNotes();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView =  findViewById(R.id.recyclerViewNotes);
        nAdaptar = new NoteAdapter(listNote, this);
        recyclerView.setAdapter(nAdaptar);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        MyAsyncTask.running = true;
        new MyAsyncTask(this).execute();
    }

    @Override
    public void onClick(View v) {
        int position = recyclerView.getChildLayoutPosition(v);
        Note m = listNote.get(position);
        lastPosition = position;
        editNote(m);
    }

    public void editNote(Note n) {
        Intent intent = new Intent(MainActivity.this, EditActivity.class);
        intent.putExtra(Intent.EXTRA_TEXT, "Edit note");
        intent.putExtra("Title", n.getNoteHeader());
        intent.putExtra("Text", n.getNoteDesc());
        startActivityForResult(intent, EDIT_REQUEST_CODE);
    }

    @Override
    public boolean onLongClick(View v) {
        int pos = recyclerView.getChildLayoutPosition(v);
        lastPosition = pos;
        final AlertDialog alertDialog = new AlertDialog.Builder(this)
                .setCancelable(false)
                .setTitle("Confirmation")
                .setMessage("Are you Sure you want to delete ?")
                .setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener)
                .show();
        return false;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_main_item_edit:
                gotoEditActivity();
                break;
            case R.id.menu_main_item_info:
                gotoActivity();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CREATE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                String newText = data.getStringExtra("DESC");
                String newTitle = data.getStringExtra("HEAD");
                String newDate = data.getStringExtra("DATE");
                if (!newTitle.equals("")) {
                    listNote.add(0, new Note(newTitle, newText, newDate));
                }
                nAdaptar.notifyDataSetChanged();
            } else {
                Toast.makeText(this, "NOTE NOT SAVED", Toast.LENGTH_SHORT).show();
            }
        }
        if (requestCode == EDIT_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                String newNoteText = data.getStringExtra("DESC");
                String newNoteTitle = data.getStringExtra("HEAD");
                String newNoteDate = data.getStringExtra("DATE");
                listNote.remove(lastPosition);
                listNote.add(0, new Note(newNoteTitle, newNoteText, newNoteDate));
                nAdaptar.notifyDataSetChanged();
            }

        }
    }



    private void saveNotes() {
        try {
            int j = 1;
            FileOutputStream fileOutputStream = getApplicationContext().openFileOutput(getString(R.string.file_name), Context.MODE_PRIVATE);
            JsonWriter jsonWriter = new JsonWriter(new OutputStreamWriter(fileOutputStream, getString(R.string.encoding)));
            jsonWriter.setIndent("  ");
            jsonWriter.beginObject();
            jsonWriter.name("number notes").value(listNote.size());
            for (int i = 1; i <= listNote.size(); i++) {
                if (listNote.get(i - 1).getNoteHeader().equals("")) {
                } else {
                    jsonWriter.name("title " + j).value(listNote.get(i - 1).getNoteHeader());
                    jsonWriter.name("date " + j).value(listNote.get(i - 1).getNoteDate());
                    jsonWriter.name("text " + j).value(listNote.get(i - 1).getNoteDesc());
                    j++;
                }
            }
            jsonWriter.endObject();
            jsonWriter.close();
        } catch (Exception e) {
            e.getStackTrace();
        }
    }

    public void whenAsyncIsDone(List<Note> lstNote) {
        this.listNote.clear();
        this.listNote.addAll(lstNote);
        nAdaptar.notifyDataSetChanged();

    }

    public void gotoActivity() {
        Intent intent = new Intent(MainActivity.this, InfoActivity.class);
        startActivity(intent);
    }

    public void gotoEditActivity() {
        Intent intent = new Intent(MainActivity.this, EditActivity.class);
        startActivityForResult(intent, CREATE_REQUEST_CODE);
    }
}
