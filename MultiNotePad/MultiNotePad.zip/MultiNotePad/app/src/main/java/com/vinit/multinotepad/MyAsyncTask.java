package com.vinit.multinotepad;

/**
 * Created by belle on 11/02/2018.
 */

import android.os.AsyncTask;
import android.util.JsonReader;
import android.util.Log;

import com.vinit.multi_notepad.R;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MyAsyncTask extends AsyncTask<Integer, Integer, List<Note>> { //  <Parameter, Progress, Result>

    private static final String TAG = "MyAsyncTask";
    public static boolean running = false;
    private MainActivity mainActivity;

    public MyAsyncTask(MainActivity ma) {
        mainActivity = ma;
    }

    @Override
    protected List<Note> doInBackground(Integer[] para) {
        List<Note> listNote = new ArrayList<>();
        boolean initList = false;
        try {
            InputStream inputStream = mainActivity.getApplicationContext().openFileInput(mainActivity.getString(R.string.file_name));
            JsonReader jsonReader = new JsonReader(new InputStreamReader(inputStream, mainActivity.getString(R.string.encoding)));

            jsonReader.beginObject();
            while (jsonReader.hasNext()) {
                String name = jsonReader.nextName();
                if (name.equals("number notes")) {
                    int pos = Integer.parseInt(jsonReader.nextString());
                    for (int i = 1; i <= pos; i++) {
                        listNote.add(new Note("header " + i, "body " + i, "Date " + i));
                    }
                    initList = true;
                } else if (name.substring(0, 4).equals("date") && initList) {
                    listNote.get(Integer.parseInt(name.substring(5)) - 1).setNoteDate(jsonReader.nextString());
                } else if (name.substring(0, 4).equals("text") && initList) {
                    listNote.get(Integer.parseInt(name.substring(5)) - 1).setNoteDesc(jsonReader.nextString());
                } else if (name.substring(0, 5).equals("title") && initList) {
                    listNote.get(Integer.parseInt(name.substring(6)) - 1).setNoteHeader(jsonReader.nextString());
                } else {
                    jsonReader.skipValue();
                }
            }
            jsonReader.endObject();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listNote;
    }

    @Override
    protected void onPostExecute(List<Note> myList) {
        super.onPostExecute(myList);
        mainActivity.whenAsyncIsDone(myList);
        running = false;
    }

}
