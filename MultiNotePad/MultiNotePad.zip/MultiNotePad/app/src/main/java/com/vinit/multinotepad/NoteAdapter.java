package com.vinit.multinotepad;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.vinit.multi_notepad.R;

import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<MyViewHolder> {

    private static final String TAG = "NoteAdapter";
    private List<Note> listNote;
    private MainActivity mainAct;

    public NoteAdapter(List<Note> noteList, MainActivity ma) {
        this.listNote = noteList;
        mainAct = ma;
    }

    @Override
    public MyViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.note_list_row, parent, false);

        view.setOnClickListener(mainAct);
        view.setOnLongClickListener((View.OnLongClickListener) mainAct);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder my, int position) {
        Note myNote = listNote.get(position);
        my.noteHeader.setText(myNote.getNoteHeader());
        if (myNote.getNoteDesc().length() < 80) {
            my.noteDesc.setText(myNote.getNoteDesc());
        } else {
            my.noteDesc.setText(myNote.getNoteDesc().substring(0, 80) + " ...");
        }
        my.noteDate.setText(myNote.getNoteDate());
    }

    @Override
    public int getItemCount() {
        return listNote.size();
    }

}
