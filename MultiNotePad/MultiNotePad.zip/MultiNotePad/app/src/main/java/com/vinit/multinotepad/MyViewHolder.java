package com.vinit.multinotepad;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.vinit.multi_notepad.R;

/**
 * Created by belle on 03/02/2018.
 */

public class MyViewHolder extends RecyclerView.ViewHolder {

    public TextView noteHeader;
    public TextView noteDesc;
    public TextView noteDate;

    public MyViewHolder(View view) {
        super(view);
        noteHeader = (TextView) view.findViewById(R.id.noteTitle);
        noteDesc = (TextView) view.findViewById(R.id.noteText);
        noteDate = (TextView) view.findViewById(R.id.noteLastSavedDate);
    }

}
