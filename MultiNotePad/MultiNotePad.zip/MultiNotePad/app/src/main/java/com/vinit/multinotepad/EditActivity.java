package com.vinit.multinotepad;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;

import com.vinit.multi_notepad.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class EditActivity extends AppCompatActivity {

    public static final int RESULT_NO_MODIFICATION = 5;
    private static final String TAG = "EditActivity";
    private EditText editDesc;
    private EditText editTitle;
    private String orgText = "";
    private String orgttl = "";
    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            switch (which) {
                case DialogInterface.BUTTON_POSITIVE:
                    Log.d(TAG, " Button : YES ");
                    saveNote();
                    break;

                case DialogInterface.BUTTON_NEGATIVE:
                    Log.d(TAG, " Button : NO ");
                    finish();
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        editDesc = (EditText) findViewById(R.id.editText);
        editTitle = (EditText) findViewById(R.id.editTitle);

        editDesc.setMovementMethod(new ScrollingMovementMethod());

        Intent intent = getIntent();
        if (intent.hasExtra(Intent.EXTRA_TEXT)) {
            orgttl = intent.getStringExtra("Title");
            editTitle.setText(orgttl);
            orgText = intent.getStringExtra("Text");
            editDesc.setText(orgText);
        } else {
            editTitle.setText("");
            editDesc.setText("");
        }
    }

    public void saveNote() {
        if (editTitle.getText().toString().equals("")) {
            setResult(RESULT_CANCELED);
        } else {
            if (editTitle.getText().toString().equals(orgttl) && editDesc.getText().toString().equals(orgText) && !editDesc.getText().toString().equals("")) {
                setResult(RESULT_NO_MODIFICATION);
            } else {

                Intent intent = new Intent(); // Used to hold results data to be returned to original activity
                intent.putExtra("DESC", editDesc.getText().toString());
                intent.putExtra("HEAD", editTitle.getText().toString());
                intent.putExtra("DATE", "" + new SimpleDateFormat("dd MMM yyyy - HH:mm").format(Calendar.getInstance().getTime()));
                setResult(RESULT_OK, intent);
            }
        }
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_edit, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_edit_item_save:
                saveNote();
                break;
            default:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (!editDesc.getText().toString().equals(orgText) || !editTitle.getText().toString().equals(orgttl)) {
            final AlertDialog alertDialog = new AlertDialog.Builder(this)
                    .setCancelable(false)
                    .setTitle("Confirmation")
                    .setMessage("Do you want to save note ?")
                    .setPositiveButton("Save", dialogClickListener)
                    .setNegativeButton("Cancel", dialogClickListener)
                    .show();
        } else {
            super.onBackPressed();
        }
    }

    public void onSoftBackPressed() {
        if (!editDesc.getText().toString().equals(orgText)) {
            final AlertDialog alertDialog = new AlertDialog.Builder(this)
                    .setCancelable(false)
                    .setTitle("Confirmation")
                    .setMessage("Do you want to save note ?")
                    .setPositiveButton("Save", dialogClickListener)
                    .setNegativeButton("Cancel", dialogClickListener)
                    .show();
        } else {
            finish();
        }
    }
}


