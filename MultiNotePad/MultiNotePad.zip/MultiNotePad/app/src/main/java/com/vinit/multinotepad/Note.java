package com.vinit.multinotepad;

public class Note {

    private String noteHeader;
    private String noteDesc;
    private String noteDate;


    public Note(String noteTitle, String noteText, String noteLastSavedDate) {
        this.noteHeader = noteTitle;
        this.noteDesc = noteText;
        this.noteDate = noteLastSavedDate;
    }

    public String getNoteHeader() {
        return this.noteHeader;
    }

    public void setNoteHeader(String newTitle) {
        this.noteHeader = newTitle;
    }

    public String getNoteDesc() {
        return this.noteDesc;
    }

    public String getNoteDate() {
        return this.noteDate;
    }

    public void setNoteDate(String newLastSavedDate) {
        this.noteDate = newLastSavedDate;
    }

    public void setNoteDesc(String newText) {
        this.noteDesc = newText;
    }

    public String toSaveFormat() {
        return "    !!Start Node !! \n" + this.noteHeader + " \n" + this.noteDate + "\n" + this.noteDesc + " !!ENDOFNOTE!! \n";
    }

    @Override
    public String toString() {
        return "Title : " + this.noteHeader + " \n" + "Date :" + this.noteDate + "\n" + this.noteDesc;
    }

}
